package com.proyectos.cuidadoconelgato;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {



    EditText etUsuarioLog, etContraseñaLog;

    Button btLogin, btRegistrarse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuarioLog = findViewById(R.id.etUsuarioLog);
        etContraseñaLog = findViewById(R.id.etContraseñaLog);
        btLogin = findViewById(R.id.btLogin);
        btRegistrarse = findViewById(R.id.btRegistrarse);

    }

    public void metIniciar(View view) {
        base_de_datos admin = new base_de_datos(this,"tienda", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String bUsuario = etUsuarioLog.getText().toString();
        String bContraseña = etContraseñaLog.getText().toString();

        String dato="123";
        /*Cursor fila = bd.rawQuery("select contraseña from persona where usuario=" +bUsuario, null);

        if (fila.moveToFirst())
            dato = fila.getString(0);

         */

        if (dato.equals(bContraseña)){
            Intent inicio = new Intent(MainActivity.this, ventana1.class);
            startActivity(inicio);

            if(bUsuario.equals("audel")){
                Intent ventanaOP = new Intent(MainActivity.this, ventanaOp.class);
                startActivity(ventanaOP);
            }

        } else
            Toast.makeText(this, "Parece que el usuario no ha sido registrado...", Toast.LENGTH_SHORT).show();

        bd.close();
    }
    public void metRegistrarse(View view){
        Intent registro = new Intent(MainActivity.this, registro.class);
        startActivity(registro);
    }

}