package com.proyectos.cuidadoconelgato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registro extends AppCompatActivity {


    EditText etNombre, etApellido, etDireccion, etCP, etUsuarioReg, etContraseñaReg;

    Button btCrear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etDireccion = findViewById(R.id.etDireccion);
        etCP = findViewById(R.id.etCP);
        etUsuarioReg = findViewById(R.id.etUsuarioReg);
        etContraseñaReg = findViewById(R.id.etContraseñaReg);

        btCrear = findViewById(R.id.btCrear);
    }

    public void metRegistro(View view){
        base_de_datos admin = new base_de_datos(this, "tienda", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String nombre = etNombre.getText().toString();
        String apellido = etApellido.getText().toString();
        String direccion = etDireccion.getText().toString();
        String cp = etCP.getText().toString();
        String usuario = etUsuarioReg.getText().toString();
        String contraseña = etContraseñaReg.getText().toString();


        ContentValues registro = new ContentValues();

        registro.put("usuario", usuario);
        registro.put("contraseña", contraseña);
        registro.put("nombre", nombre);
        registro.put("apellido", apellido);
        registro.put("direccion", direccion);
        registro.put("cp", cp);



        // los inserto en la base de datos
        bd.insert("persona", null, registro);

        bd.close();

        Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

        // ponemos los campos a vacío para insertar el siguiente usuario
        limpiar();

        Intent regreso = new Intent(registro.this, MainActivity.class);

        startActivity(regreso);


    }


    public void limpiar(){
        etNombre.setText(""); etApellido.setText(""); etDireccion.setText(""); etCP.setText(""); etUsuarioReg.setText(""); etContraseñaReg.setText("");

    }

}