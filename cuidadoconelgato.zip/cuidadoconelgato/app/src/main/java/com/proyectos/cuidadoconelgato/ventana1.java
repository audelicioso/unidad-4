package com.proyectos.cuidadoconelgato;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;


public class ventana1 extends AppCompatActivity {

    ImageView ivCodigoQR;
    Button btQR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana1);
        ivCodigoQR = findViewById(R.id.ivCodigoQR);
        btQR = findViewById(R.id.btQR);
    }

    public void generarQR (View view){
        String pedido="camisa negra 140";
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(
                    pedido,
                    BarcodeFormat.QR_CODE,
                    750,
                    750);
            ivCodigoQR.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}